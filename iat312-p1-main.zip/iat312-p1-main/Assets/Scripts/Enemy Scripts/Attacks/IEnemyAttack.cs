public interface IEnemyAttack
{
    void Attack();
}

public interface IPatrol
{
    void Patrol();
}
